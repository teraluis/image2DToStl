
public class Triangle {
	//Attributs
	private Point a,b,c;
//	private Vecteur vecteur; DANS UN FICHIER STL LE VECTEUR NORMAL EST PAR DEFAUT (0,0,0) 
	
	
	//Constructeurs
	public Triangle(){
		Point a = new Point(0,0,0);
		Point b = new Point(0,0,0);
		Point c = new Point(0,0,0);
		this.a=a;
		this.b=b;
		this.c=c;
//		vecteur = new Vecteur(a,b,c);
	}
	
	public Triangle(Point a, Point b, Point c){
		this.a=a;
		this.b=b;
		this.c=c;
//		vecteur = new Vecteur(a,b,c);
	}

	//GET ET SET
	public Point getA() {
		return a;
	}

	public void setA(Point a) {
		this.a = a;
	}

	public Point getB() {
		return b;
	}

	public void setB(Point b) {
		this.b = b;
	}

	public Point getC() {
		return c;
	}

	public void setC(Point c) {
		this.c = c;
	}

	//Methode
	public String affiche(){
		return("A : "+a.affichePoint()+"\nB : "+b.affichePoint()+"\nC : "+c.affichePoint());
	}
/*	public Vecteur getVecteur() {
		return vecteur;
	}

	public void setVecteur(Vecteur vecteur) {
		this.vecteur = vecteur;
	}	
*/	
	
}
