import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.ImageObserver;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.util.ArrayList;
import java.util.Vector;


public class ImageToStl {
	//attributs
	private int[][] tabPixelZ; // image matricielle
	private File fichierStl;
	private Face[][] tabFace; // tableau de face non modifié
	private ArrayList<Face> listFace; //liste des faces modifiées 
	
	//constructeurs
	
	public ImageToStl(Image imageGris){
		BufferedImage buffer = (BufferedImage) imageGris;
		tabPixelZ = new int[buffer.getHeight()][buffer.getWidth()];
		fichierStl = new File("fichierSTL");
		listFace = new ArrayList<Face>();
		tabFace = new Face[buffer.getHeight()][buffer.getWidth()];
	}

	
	//******************GET ET SET******************
	public int[][] getTabPixelZ() {
		return tabPixelZ;
	}

	public void setTabPixelZ(int[][] tabPixelZ) {
		this.tabPixelZ = tabPixelZ;
	}



	public File getFichierStl() {
		return fichierStl;
	}


	public void setFichierStl(File fichierStl) {
		this.fichierStl = fichierStl;
	}


	public Face[][] getTabFace() {
		return tabFace;
	}


	public void setTabFace(Face[][] tabFace) {
		this.tabFace = tabFace;
	}


	public ArrayList<Face> getListFace() {
		return listFace;
	}


	public void setListFace(ArrayList<Face> listFace) {
		this.listFace = listFace;
	}
	//*****************Methodes********************
/*
	public void handlesinglepixel(int x, int y, int pixel) {
	      int alpha = (pixel >> 24) & 0xff;
	      int red   = (pixel >> 16) & 0xff;
	      int green = (pixel >>  8) & 0xff;
	      int blue  = (pixel      ) & 0xff;
	      // Deal with the pixel as necessary...
	 }

	 public void handlepixels(Image img, int x, int y, int w, int h) {
	      int[] pixels = new int[w * h];
	      PixelGrabber pg = new PixelGrabber(img, x, y, w, h, pixels, 0, w);
	      try {
	          pg.grabPixels();
	      } catch (InterruptedException e) {
	          System.err.println("interrupted waiting for pixels!");
	          return;
	      }
	      if ((pg.getStatus() & ImageObserver.ABORT) != 0) {
	          System.err.println("image fetch aborted or errored");
	          return;
	      }
	      for (int j = 0; j < h; j++) {
	          for (int i = 0; i < w; i++) {
	              handlesinglepixel(x+i, y+j, pixels[j * w + i]);
	          }
	      }
	 }
*/
	   public void convertTo2DUsingGetRGB(BufferedImage image) {
		      int width = image.getWidth();
		      int height = image.getHeight();
		      int[][] result = new int[height][width];

		      for (int row = 0; row < height; row++) {
		         for (int col = 0; col < width; col++) {
		            //Les bits sont signés et nous les voulons non signés. 
		        	 result[row][col] = image.getRGB(col, row) & 0xFF;
		            
		         }
		      }

		      this.tabPixelZ=result;
		   }
	
	/*
	//Convertie une image en matrice d'entier 
	 * source = http://stackoverflow.com/questions/6524196/java-get-pixel-array-from-image
	   public static int[][] imageToInt(BufferedImage image) throws ArrayIndexOutOfBoundsException {
		   //Creation d'un tab de byte 
		      
		   	  final byte[] pixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		      final int width = image.getWidth();
		      final int height = image.getHeight();
		      final boolean hasAlphaChannel = image.getAlphaRaster() != null;

		      int[][] result = new int[height][width];
		      if (hasAlphaChannel) {
		         final int pixelLength = 4;
		         for (int pixel = 0, row = 0, col = 0; pixel < pixels.length; pixel += pixelLength) {
		            int argb = 0;
		            argb += (((int) pixels[pixel] & 0xff) << 24); // alpha
		            argb += ((int) pixels[pixel + 1] & 0xff); // blue
		            argb += (((int) pixels[pixel + 2] & 0xff) << 8); // green
		            argb += (((int) pixels[pixel + 3] & 0xff) << 16); // red
		            result[row][col] = argb;
		            col++;
		            if (col == width) {
		               col = 0;
		               row++;
		            }
		         }
		      } else {
		         final int pixelLength = 3;
		         for (int pixel = 0, row = 0, col = 0; pixel < (pixels.length-1); pixel += pixelLength) {
		            int argb = 0;
		            argb += -16777216; // 255 alpha
		            argb += ((int) pixels[pixel] & 0xff); // blue
		            argb += (((int) pixels[pixel + 1] & 0xff) << 8); // green
		            argb += (((int) pixels[pixel + 2] & 0xff) << 16); // red
		            result[row][col] = argb;
		            col++;
		            if (col == width) {
		               col = 0;
		               row++;
		            }
		         }
		      }

		      return result;
		      
		   }
*/
//Creation du tableau de Face(sans triangle) et va être modifié 
	   public void createTabFace(){
		   int i,j;
		   int imax = tabPixelZ.length;
		   int jmax = tabPixelZ[0].length;
		   tabFace = new Face[imax][jmax];
		   for (i=0; i<imax;i++){
			   for (j=0; j<jmax; j++){
				   Point a = new Point(i,j,tabPixelZ[i][j]);
				   Point b = new Point(i,j+1,tabPixelZ	[i][j]);
				   Point c = new Point(i+1,j+1,tabPixelZ[i][j]);
				   Point d = new Point(i+1,j,tabPixelZ[i][j]);
				   double valeur = tabPixelZ[i][j];
				   Face face = new Face (a,b,c,d);
				   face.setValeur(tabPixelZ[i][j]);
				   tabFace[i][j] = face; 
			   }
		   }
	   }
	   
//Avec triangle
	   public void createSurface(){
		   
//********Création des faces de la première colonne + paroi intérieure gauche du cadre**********
		 
		   System.out.println("***PREMIERE COLONNE***\n");
		   for (int i =0 ; i<tabFace.length; i++){
	
			   Face f =tabFace[0][i];
			   Triangle t1 = new Triangle (f.getA(),f.getB(),f.getC());
			   Triangle t2 = new Triangle (f.getA(),f.getC(),f.getD());
/*			   t1.getVecteur().normal();// à vérifier
*			   t2.getVecteur().normal();
*/			   f.setT1(t1);
			   f.setT2(t2);
			   System.out.println("**T1**");
			   System.out.println(t1.affiche());
			   System.out.println("**T2**");
			   System.out.println(t2.affiche()+"\n");
			   listFace.add(f);			   
			   listFace.add(Face.paroieInv(f.getA(),f.getD()));
			   
		   }//fin for
		   
		   
 //********FIN création des faces de la première colonne**********		   
		   
		   
		   // créer une face temporaire que l'on traitera (forme courante)
		   
		   Face temp = new Face();
		   System.out.println("\n--FACE TEMP INITIAL--\n");
		   System.out.println(temp);
		   
		   //r = rang (ligne)
		   int comparateur; // nombre de pixel mangé
		for (int r = 0; r<tabFace.length; r++){
				   //p = pixel (colonne)
			System.out.println("*******");
				   for (int p = 1;p<tabFace[0].length;p+=comparateur){
					  
					   comparateur = 1;
					   int z = (int) tabFace[r][p].getValeur(); //valeur=couleur
			System.out.println("z :"+z);		   
	//********Algo glouton à droite*********
					   System.out.println("\nDEBUT COMPARATEUR");
					   while ( ((p+comparateur)<(tabFace[0].length)) && z == ((int) tabFace[r][p+comparateur].getValeur())/16){
						   comparateur++; // si même valeur = mangé  
					   }
					   System.out.println("Comparateur :"+comparateur);
					   if(comparateur > 1){
						   // pixels a fusionner
						   //fusionner car ils ont la même valeur : fusionFace();
						   temp = Face.fusionFace(tabFace[r][p], tabFace[r][p+comparateur-1]); 
						   //fusionne le coté gauche de la case courante et le coté droit de la dernière case
					   } 
					   
					   else {
						   temp = tabFace[r][p];
					   }
					   System.out.println("\n--FACE TEMP APRES FUSION--\n");
					   System.out.println(temp);

					   
	//*******Fin Algo glouton à droite... temp = face courante à traiter********
					   
	//******Début inclinaison + ajout de la surface*******				   
					   Face prec = tabFace[r][p-1]; // face précedente 
					   System.out.println("\n-Face precedente-\n");
					   System.out.println(prec);
					   
					   
					   if((int)(tabFace[r][p].getValeur() / 16) == (int) (prec.getValeur() / 16)){
						   System.out.println("Même couleur");
						   //si même catégorie de couleur
						   // on garde en mémoire la valeur des points A et D courants pour faire les petits triangles sur le côté 
						   Point atemp = temp.getA();
						   Point dtemp = temp.getD();
						   
						   // Pour incliner il faut que le A et D courant deviennent B' et C'
						   temp.setA(prec.getB());
						   temp.setD(prec.getC());
						   temp.setT1(new Triangle (temp.getA(),temp.getB(),temp.getC()));
						   temp.setT2(new Triangle (temp.getA(),temp.getC(),temp.getD()));
						   listFace.add(temp);
						   System.out.println("-Face temp ajouté-\n");
						   System.out.println(temp);
						   System.out.println("t1");
						   System.out.println(temp.getT1().affiche());
						   System.out.println("t2");
						   System.out.println(temp.getT2().affiche());						   
						   
						   //crée les deux petits triangles sur le côté
						   Triangle t1 = new Triangle(temp.getA(),temp.getB(),atemp);
						   Triangle t2 = new Triangle(temp.getD(),temp.getC(),dtemp);
/*						   t1.getVecteur().normal();// à vérifier
						   t2.getVecteur().normal();
*/						   Face f = new Face(t1,t2,0);
						   listFace.add(f); // On triche on n'utilise plus la valeur donc 0	  
						   System.out.println("\n--Face petit triagle ajouté--\n");
						   System.out.println(f);
						   
						   System.out.println("t1");
						   System.out.println(t1.affiche());
						   System.out.println("t2");
						   System.out.println(t2.affiche());						   
						   
					   }
				   
					   else { // si différence de couleur (valeur) importante pas d'inclinaison donc on crée une paroie 

						   System.out.println("Différente couleur");
						   temp.setT1(new Triangle (temp.getA(),temp.getB(),temp.getC()));
						   temp.setT2(new Triangle (temp.getA(),temp.getC(),temp.getD()));
						   listFace.add(temp);
						   System.out.println("-Face temp ajouté-\n");
						   System.out.println(temp);
						   System.out.println("t1");
						   System.out.println(temp.getT1().affiche());
						   System.out.println("t2");
						   System.out.println(temp.getT2().affiche());						   

						   Triangle t1 = new Triangle(prec.getB(),temp.getA(),temp.getD());
						   Triangle t2 = new Triangle(prec.getB(),temp.getD(),prec.getC());
/*						   t1.getVecteur().normal();// à vérifier
						   t2.getVecteur().normal();
*/						   Face f = new Face(t1,t2,0);
						   listFace.add(f); // On triche on n'utilise plus la valeur donc 0	   
						   System.out.println("\n--FACE ajouté--\n");
						   System.out.println(f);
					   }
	//*****Fin inclinaison*******				   
	//*****création des paroies*******
					  //si c'est la première ligne
					   if (r==0) {
						   
						   Face f1 = Face.paroieInv(temp.getA(), temp.getB());
						   listFace.add(f1);
						   Face f2 = Face.paroie(temp.getC(),temp.getD());
						   listFace.add(f2); // paroie bas  (CD)
					   }
					 //si c'est la dernière ligne
					   else if (r==tabFace.length-1) {
						   Face f1 = Face.paroie(temp.getA(),temp.getB());
						   Face f2 = Face.paroieInv(temp.getD(), temp.getC());
						   listFace.add(f2);
						   listFace.add(Face.paroie(temp.getA(),temp.getB())); // paroie haut (AB) 
						   listFace.add(Face.paroieInv(temp.getD(), temp.getC()));
					   }   
					   else {
						   Face f1 = Face.paroie(temp.getA(),temp.getB());
						   Face f2 = Face.paroie(temp.getC(),temp.getD());
						   listFace.add(f1); // paroie haut (AB) 
						   listFace.add(f2); // paroie bas  (CD)  
					   }
					   //Si c'est le dernier pixel de la ligne ( le plus à droite)
					   if ( p == tabFace[0].length-1){ listFace.add(Face.paroieInv(temp.getB(),temp.getC()));}
					   
					   
					   
					
					   
			   }//fin for p	    
	   }//fin for r
		
			   
	   }//fin createSurface
	   
	   public void cadre( double coef ){
		   
		   //Création du contour
		   // création des points dans un ordre de spirale
		   double jmax = tabPixelZ[0].length;
		   double imax = tabPixelZ.length;
		   Point a = new Point((-1*coef),(-1*coef),256);
		   Point b = new Point((-1*coef),0,256);
		   Point c = new Point((-1*coef),jmax,256);
		   Point d = new Point((-1*coef),jmax+coef,256);
		   Point e = new Point(imax+coef,jmax+coef,256);
		   Point f = new Point(imax+coef,jmax,256);
		   Point g = new Point(imax+coef,0,256);
		   Point h = new Point(imax+coef,(-1*coef),256);
		   Point i = new Point(0,0,256);
		   Point j = new Point(0,jmax,256);
		   Point k = new Point(imax,jmax,256);
		   Point l = new Point(imax,0,256);
		   
		   //GROUND ZERO
		   
		   Point a0 = new Point((-1*coef),(-1*coef),0);
		   Point d0 = new Point((-1*coef),jmax+coef,0);
		   Point e0 = new Point(imax+coef,jmax+coef,0);		   
		   Point h0 = new Point(imax+coef,(-1*coef),0);
		   
		   // surface du contour
		   listFace.add(Face.faceBis(a, b, g,h));
		   listFace.add(Face.faceBis(c, d, e,f));
		   listFace.add(Face.faceBis(b, c, j,i)); // Top
		   listFace.add(Face.faceBis(l, k, f,g));
		   
		   //Paroie extérieur 
		   listFace.add(Face.paroie(a, h));
		   listFace.add(Face.paroie(d, a));
		   listFace.add(Face.paroie(e, d));
		   listFace.add(Face.paroie(h, e));
		   
		   //Base
		   listFace.add(Face.faceBis(a0,d0,e0,h0));

	   }


	 
	   
	   
	   
}//FIN CLASSE
