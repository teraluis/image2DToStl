import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import javax.imageio.ImageIO;



public class TestProjet  {

	public static void main (String[] args) throws IOException{
		String cheminImg, cheminArr;
		
		cheminImg = new String("mibde.png");
		cheminArr = new String("photogris.png");
		
	
		//source: http://www.fobec.com/java/1078/convertir-une-image-nuance-gris.html
		try {
	            System.out.println("D�but de conversion....");
	            //Ouverture du fichier
	            File fichierImage = new File(cheminImg);
	            BufferedImage imagesrc = ImageIO.read(fichierImage);
	            //Convertion en gris
	            BufferedImage imagedst = new BufferedImage(imagesrc.getWidth(), imagesrc.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
	            Graphics g = imagedst.getGraphics();
	            g.drawImage(imagesrc, 0, 0, null);
	            g.dispose();
	            
	            //Enregistrer l'image au format PNG
	            File outFile = new File(cheminArr);
	            ImageIO.write(imagedst, "JPG", outFile);
	            System.out.println("Fin de conversion....");
	        } //Fin Try
		catch (IOException ex) {
	        }//Fin catch
	
	
	
		File fichierGris = new File(cheminArr);
		Image imageTest = ImageIO.read(fichierGris);
		System.out.println("Instanciation de l'objet");
		ImageToStl imgTest = new ImageToStl(imageTest);
		System.out.println("FIN instanciation de l'objet");
		
		System.out.println("Creation tableau de int");
		//tabPixelZ initialis�
		imgTest.convertTo2DUsingGetRGB((BufferedImage) imageTest);
		System.out.println("Fin creation tab de int");
		
		System.out.println("Creation tab de faces");
		imgTest.createTabFace();
		System.out.println("fin Creation tab de faces");
		
		System.out.println("Creation surface");
		imgTest.createSurface();
		System.out.println("fin Creation surface");
		
		
		System.out.println("nombres de face : " + imgTest.getListFace().size());
		
		System.out.println("Creation du fichier");
		FichierASCII fichier = new FichierASCII(imgTest.getListFace());
		fichier.generation();
		System.out.println("fin Creation fichier");
	}
}
		/*
		for (int i = 0 ; i<4 ; i++){
			System.out.println("\n");
			for (int j = 0 ; j <4;j++){
			int	val = imgTest.getTabPixelZ()[i][j];
			System.out.println("i : "+i+" j :" +j+ " valeur :"+val + " hexa : "+String.format("%06X",val));
			
			}
		}
		
	}//FIN MAIN

}//FIN CLASSE

*/