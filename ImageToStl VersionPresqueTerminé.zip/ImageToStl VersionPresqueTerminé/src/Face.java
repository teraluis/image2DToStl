
public class Face {
	//Attributs
	private double valeur; //Equivalent à la hauteur,épaisseur de la plaque , au z des points
	private Triangle t1,t2; // t1 = abc t2 =acd
	private Point a , b , c , d;
	
	//Constructeurs
	
	public Face(Triangle t1, Triangle t2, double valeur){
		this.valeur=valeur;
		this.t1=t1;
		this.t2=t2;
		a=t1.getA();
		b=t1.getB();
		c=t2.getC();
		d=t2.getC();
		
	}
	
	public Face(Triangle t1){
		this.t1=t1;
		this.t2=null;
	}
	public Face(Point a , Point b , Point c , Point d) {// ABCD
		this.a=a;
		this.b=b;
		this.c=c;
		this.d=d;
	}
	public Face(Point a , Point b , Point c , Point d, double valeur) {// ABCD
		this.a=a;
		this.b=b;
		this.c=c;
		this.d=d;
		this.valeur = valeur;
	}
	
	public Face(){
		this(new Point(),new Point(),new Point(),new Point());
		
	}

	
	//Methodes
	
	
	public static Face faceBis(Point a, Point b , Point c , Point d){
	//comme le constructeur face mais crée les triangles.
		Face f = new Face(a,b,c,d);
		Triangle t1 = new Triangle (a,b,c);
		Triangle t2 = new Triangle (a,c,d);		
/*		t1.getVecteur().normal();// à vérifier
		t2.getVecteur().normal();
*/		f.setT1(t1);
		f.setT2(t2);
		return (f); 	
	}
	
	public double getValeur() {
		return valeur;
	}

	public void setValeur(double valeur) {
		this.valeur = valeur;
	}

	public Triangle getT1() {
		return t1;
	}

	public void setT1(Triangle t1) {
		this.t1 = t1;
	}

	public Triangle getT2() {
		return t2;
	}

	public void setT2(Triangle t2) {
		this.t2 = t2;
	}
	
	public double compareZ(Face p){
		double x = valeur-p.getValeur();
		if (x<0 || x>0) {
			return -1;
		}
		else { //Verifier le cas des arrondis
			return valeur;
		}

	}

	public Point getA() {
		return a;
	}

	public void setA(Point a) {
		this.a = a;
	}

	public Point getB() {
		return b;
	}

	public void setB(Point b) {
		this.b = b;
	}

	public Point getC() {
		return c;
	}

	public void setC(Point c) {
		this.c = c;
	}

	public Point getD() {
		return d;
	}

	public void setD(Point d) {
		this.d = d;
	}	
	
	
	
	public static Face fusionFace(Face f1, Face f2){
		// Crée une nouvelle face avec les nouveaux points
		return (new Face (f1.getA(),f2.getB(),f2.getC(),f1.getD()));
	}
	
	public static Face paroie( Point p1, Point p2 ){ //p1 point gauche p2 point droit
		Point p1bis =  p1;
		p1bis.setZ(255);
		Point p2bis =  p2;
		p2bis.setZ(255);
		Triangle t1 = new Triangle (p1,p2,p2bis);
		Triangle t2 = new Triangle (p1,p2bis,p1bis);
/*		t1.getVecteur().normal();// à vérifier
		t2.getVecteur().normal();
*/		return (new Face (t1,t2,0)); // valeur = 0 car c'est une paroie 
	}
	
	public static Face paroieInv( Point p1, Point p2 ){ //p1 point gauche p2 point droit
		Point p1bis =  p1;
		p1bis.setZ(0);
		Point p2bis =  p2;
		p2bis.setZ(0);
		Triangle t1 = new Triangle (p1,p2,p2bis);
		Triangle t2 = new Triangle (p1,p2bis,p1bis);
/*		t1.getVecteur().normal();// à vérifier
		t2.getVecteur().normal();
*/		return (new Face (t1,t2,0)); // valeur = 0 car c'est une paroie 
	}	

	
	
	
}
