
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;


public class FichierASCII {

	private ArrayList<Face> faces;
	private PrintWriter test;
	
	public FichierASCII(ArrayList<Face> faces) throws IOException {
		this.faces = faces;
		test  = new PrintWriter(new FileWriter("fichierSTL.stl"));
	}
	
	
	public void generation(){
		test.println("solid");
			for(int f = 0; f<faces.size(); f++){
				Triangle[] triangles = new Triangle[2];
				triangles[0] = faces.get(f).getT1();
				triangles[1] = faces.get(f).getT2();
				for(int t = 0; t < 2; t++){
					test.println("facet normal:0 0 0");
					test.println("outer loop");
						
					Triangle tri = triangles[t];
					test.println("vertex: "+ tri.getA().getX() + " " + tri.getA().getY() + " " + (tri.getA().getZ())/10);
					test.println("vertex: "+ tri.getB().getX() + " " + tri.getB().getY() + " " + (tri.getB().getZ())/10);
					test.println("vertex: "+ tri.getC().getX() + " " + tri.getC().getY() + " " + (tri.getC().getZ())/10);
					test.println("endloop");
				}
				
			}
		test.println("end solid");
		test.close();
	}
}
