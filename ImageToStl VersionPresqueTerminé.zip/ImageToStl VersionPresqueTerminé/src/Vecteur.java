
public class Vecteur {
	private Point a,b,c;
	private double abx;
	private double aby;
	private double abz;
	private double acx;
	private double acy;
	private double acz;
	private Point n;
	
	public Vecteur(Point a,Point b,Point c){
		this.a=a;
		this.b=b;
		this.c=c;
		distanceAB(this.a,this.b);
		distanceAC(this.a,this.c);
	}
	
	public void distanceAB(Point a,Point b){
		 abx=b.getX() -a.getX();
		 aby=b.getY() - a.getY();
		 abz=b.getZ()- a.getZ();
	}
	
	public void distanceAC(Point a,Point c){
		acx=c.getX()-a.getX();
		acy=c.getY()-a.getY();
		acz=c.getZ()-a.getZ();
	}
	
	// instancier vector normal unitaire
	public void normal(){
		double x,y,z;
		x = (abx*acz)-(acz*aby);
		y = (abz*acx)-(abx*abz);
		z = (abx*acy)-(aby*acz);
		if(z<0){
			z*=-1;
			x*=-1;
			y*=-1;
		}
		double magnitude = Math.sqrt(Math.pow(x,2) + Math.pow(y,2) + Math.pow(z,2));
		n = new Point(x/magnitude,y/magnitude,z/magnitude);
	}
}
