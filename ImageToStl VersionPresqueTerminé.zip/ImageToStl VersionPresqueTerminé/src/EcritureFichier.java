

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class EcritureFichier
{
  public static void main(String[] argv) throws IOException
  {
	/*Le cube n'est pas complet*/
	/*source : http://www.infres.enst.fr/~hudry/coursJava/fichiersEtSaisies/ecrireFichierTexte.html */
	/*Chose � faire : /!\ Cr�er une boucle for pour impl�menter les coordonn�es des sommets */  
    PrintWriter test;
    /*test.println("");*/
    /*On cr�e un fichier � partir de FileWriter() et on �crit sur ce fichier avec PrintWriter*/
    test = new PrintWriter(new FileWriter("allo2.stl"));
    
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 0.500000 1.000000");
    test.println("vertex -0.500000 0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex 0.500000 -0.500000 0.000000");
    test.println("vertex -0.500000 -0.500000 0.000000");
    test.println("vertex -0.500000 0.500000 0.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 0.000000");
    test.println("vertex -0.500000 -0.500000 1.000000");
    test.println("vertex -0.500000 0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 1.000000");
    test.println("vertex -0.500000 0.500000 1.000000");
    test.println("vertex -0.500000 0.500000 0.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 0.000000");
    test.println("vertex 0.500000 0.500000 0.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 0.500000 0.000000");
    test.println("vertex 0.500000 0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 0.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    test.println("facet normal: 0 0 0");
    test.println("outer loop");
    test.println("vertex -0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("vertex 0.500000 -0.500000 1.000000");
    test.println("endloop");
    test.println("enfacet");
    /*close() permet de fermer le flux et lib�re les ressources syst�me qui lui sont associ�es. */
    test.close();
  }
} 

